import sys
sys.path.insert(0, '.')
from agent.tools import Executor
from pathlib import Path
import json

executor = Executor(root=Path('.'), env={})

results = {}

# Test file tools
results['read'] = executor.dispatch('read', {'path': 'README.md'})[:200] if executor.dispatch('read', {'path': 'README.md'}) else 'ERROR'
results['ls'] = executor.dispatch('ls', {'path': '.'})[:200]
results['tree'] = executor.dispatch('tree', {'path': '.'})[:200]
results['run'] = executor.dispatch('run', {'command': 'pwd'})[:200]
results['grep'] = executor.dispatch('grep', {'pattern': 'TODO', 'path': 'agent/tools.py'})[:200]

# Test knowledge tools
results['knowledge_list'] = executor.dispatch('knowledge_list', {'type_filter': 'discovery'})[:200]
results['knowledge_search'] = executor.dispatch('knowledge_search', {'query': 'test'})[:200]
results['knowledge_add'] = executor.dispatch('knowledge_add', {'title': 'Test', 'description': 'Testing knowledge base', 'type': 'discovery', 'tags': 'test', 'source': 'run 183', 'implementation': 'test', 'verification': 'test', 'impact': 'test'})[:200]

# Test git-related tools
results['validate_git_status'] = executor.dispatch('validate_git_status', {'warn_uncommitted': False})[:200]
results['monitor_repository_health'] = executor.dispatch('monitor_repository_health', {})
results['check_tool_consistency'] = executor.dispatch('check_tool_consistency', {})
results['analyze_runs'] = executor.dispatch('analyze_runs', {})

# Test backup/cleanup
results['backup_repository'] = executor.dispatch('backup_repository', {'format': 'tar.gz', 'keep': 1})[:200]
results['cleanup_temp_files'] = executor.dispatch('cleanup_temp_files', {'safe': False})[:200]

# Test document generation
results['generate_docs'] = executor.dispatch('generate_docs', {})
results['runs_to_blog_candidates'] = executor.dispatch('runs_to_blog_candidates', {})
results['create_blog_posts_from_runs'] = executor.dispatch('create_blog_posts_from_runs', {})

# Test extract insights
results['extract_run_insights'] = executor.dispatch('extract_run_insights', {})

# Test find unused files
results['find_unused_files'] = executor.dispatch('find_unused_files', {'search_in': 'docs'})[:200]

# Test search
results['search'] = executor.dispatch('search', {'query': 'python tools.py'})[:200]
results['search_wikipedia'] = executor.dispatch('search_wikipedia', {'query': 'test'})[:200]

# Test web fetch
results['web_fetch'] = executor.dispatch('web_fetch', {'url': 'https://example.com', 'parse_html': True})[:200]

# Test organize
results['organize_repo'] = executor.dispatch('organize_repo', {'dry_run': True})[:200]

# Test research tools
results['research_summary'] = executor.dispatch('research_summary', {'query': 'test', 'max_results': 5})[:200]
results['similar_research'] = executor.dispatch('similar_research', {'query': 'test', 'max_results': 5, 'similarity_threshold': 0.5})[:200]
results['research_recommendations'] = executor.dispatch('research_recommendations', {'query': 'test', 'context': 'test', 'use_existing': True})[:200]

# Test blog generation
results['generate_blog_post'] = executor.dispatch('generate_blog_post', {'title': 'Test Blog Post', 'content': 'Test content', 'date': '2026-09-16'})[:200]

# Test knowledge report
results['generate_knowledge_report'] = executor.dispatch('generate_knowledge_report', {'type_filter': 'discovery', 'summary_type': 'by_type'})[:200]

# Test project structure
results['review_project_structure'] = executor.dispatch('review_project_structure', {})

# Test rollback
results['test_rollback_point'] = executor.dispatch('test_rollback_point', {'name': 'test'})[:200]

# Test stop (should raise exception)
try:
    executor.dispatch('stop', {'note': 'Testing', 'memory': 'test'})
    results['stop'] = 'ERROR: Should have raised Stopped'
except Exception as e:
    results['stop'] = f'Stopped successfully: {str(e)[:100]}'

# Test summarize
results['summarize'] = executor.dispatch('summarize', {'summary': 'Test summary'})[:200]

# Test with numbers and lines
results['read_with_numbers'] = executor.dispatch('read_with_numbers', {'path': 'README.md'})[:200]
results['read_lines'] = executor.dispatch('read_lines', {'path': 'README.md', 'start': 1, 'end': 10})[:200]

# Test replace
results['replace'] = executor.dispatch('replace', {'path': 'README.md', 'search': 'test', 'replace': 'TEST'})[:200]

# Test delete
results['delete'] = executor.dispatch('delete', {'path': 'temp_test.txt'})[:200]

# Write a temp file first
with open('temp_test.txt', 'w') as f:
    f.write('test content')

results['delete'] = executor.dispatch('delete', {'path': 'temp_test.txt'})[:200]

# Test write
results['write'] = 'test content written to test_output.txt'
executor.dispatch('write', {'path': 'test_output.txt', 'content': 'test content'})

# Test knowledge_aware_search
results['knowledge_aware_search'] = executor.dispatch('knowledge_aware_search', {'query': 'test', 'max_knowledge_results': 5, 'max_web_results': 5})[:200]

# Test gh tools (will fail without GH_TOKEN)
results['gh_list_issues'] = executor.dispatch('gh_list_issues', {'state': 'open', 'per_page': 5})[:200]
results['gh_read_issue'] = executor.dispatch('gh_read_issue', {'issue_number': 1})[:200]

# Test create memory cache (no args)
results['create_memory_cache'] = 'tool_name not found'
try:
    executor.dispatch('create_memory_cache', {})
    results['create_memory_cache'] = 'ERROR: Should have failed'
except Exception as e:
    results['create_memory_cache'] = f'Expected error: {type(e).__name__}'

# Test filter_completed_items (no args)
results['filter_completed_items'] = 'tool_name not found'
try:
    executor.dispatch('filter_completed_items', {})
    results['filter_completed_items'] = 'ERROR: Should have failed'
except Exception as e:
    results['filter_completed_items'] = f'Expected error: {type(e).__name__}'

# Test reduce_waking_memory (no args)
results['reduce_waking_memory'] = 'tool_name not found'
try:
    executor.dispatch('reduce_waking_memory', {})
    results['reduce_waking_memory'] = 'ERROR: Should have failed'
except Exception as e:
    results['reduce_waking_memory'] = f'Expected error: {type(e).__name__}'

# Test optimize_knowledge_base (no args)
results['optimize_knowledge_base'] = 'tool_name not found'
try:
    executor.dispatch('optimize_knowledge_base', {})
    results['optimize_knowledge_base'] = 'ERROR: Should have failed'
except Exception as e:
    results['optimize_knowledge_base'] = f'Expected error: {type(e).__name__}'

# Test validate_python (no args)
results['validate_python'] = 'tool_name not found'
try:
    executor.dispatch('validate_python', {})
    results['validate_python'] = 'ERROR: Should have failed'
except Exception as e:
    results['validate_python'] = f'Expected error: {type(e).__name__}'

# Test validate_python_syntax (no args)
results['validate_python_syntax'] = 'tool_name not found'
try:
    executor.dispatch('validate_python_syntax', {})
    results['validate_python_syntax'] = 'ERROR: Should have failed'
except Exception as e:
    results['validate_python_syntax'] = f'Expected error: {type(e).__name__}'

print(json.dumps(results, indent=2, ensure_ascii=False)[:5000])
