"""What the agent sees when it wakes up. This file is the agent's.

Deliberately small. It gets the time, how long it has been running, its memory,
the file tree and any note from the owner. It does not get transcripts, journal
excerpts or logs of what it did before: those are for people to read, and
feeding them back only teaches it to re-read its own noise. What carried over
is the paragraph it wrote at the end of the last run, and nothing else.
"""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime
from pathlib import Path

from engine.guard import PROTECTED

SKIP = {".git", "__pycache__", ".venv", "node_modules", "journal"}


def tree(root: Path) -> str:
    # Show the important parts of the project
    lines = []
    important_dirs = {"agent", "docs", "engine", "notes", "world_knowledge"}
    important_files = {".gitignore", "ANSWER.md", "GOALS.md", "MEMORY.md", "PROJECT.md", "NOTE.md", "WAKE"}
    
    # First add important directories
    for path in sorted(root.glob("*")):
        if path.is_dir() and path.name in important_dirs:
            lines.append(f"{path.name}/")
    
    # Then add important files at root (skip hidden files and .git)
    for path in sorted(root.glob("*")):
        if path.is_file() and path.name in important_files:
            lines.append(path.name)
    
    return "\n".join(lines)


def read(root: Path, name: str) -> str:
    path = root / name
    return path.read_text(encoding="utf-8", errors="replace") if path.is_file() else ""


def prompt(root: Path) -> str:
    return read(root, "agent/prompt.md")


def waking(root: Path, run: int, days: int, last: str, now: datetime,
           turns: int, message: str = "") -> str:
    parts = [
        f"It is {now:%A %Y-%m-%d %H:%M} UTC. This is run {run}.",
        f"You have been running for {days} days." if days else "You started today.",
        f"Last run ended: {last}." if last else "",
        f"You have up to {turns} turns.",
        "",
        "Fixed, and not yours to change:",
        "  " + "  ".join(PROTECTED),
        "Everything else is yours, agent/ included. Change it when it helps.",
        "",
        f"WAKE says {(read(root, 'WAKE').strip().splitlines() or ['60'])[0]}"
        " minutes until you wake again. You may change that.",
        "",
        "Files:",
        tree(root),
    ]



    memory = read(root, "MEMORY.md").strip()
    
    # NOTE.md is owner instructions
    note = read(root, "NOTE.md")
    if note:
        parts.append("")
        parts.append("NOTE.md:")
        parts.append(note)
    # Keep last 2 runs
    lines = memory.split("\n")
    run_lines = [i for i in range(len(lines) - 1, -1, -1) if "## run" in lines[i]]
    start_idx = run_lines[1] if len(run_lines) >= 2 else 0
    recent_memory = "\n".join(lines[start_idx:])
    parts += ["", "Your memory (last 2 runs):", recent_memory]

    # Add a hint about long-term goals if the file exists
    goals_path = root / "GOALS.md"
    if goals_path.exists():
        parts += ["", "Long-term goals in GOALS.md."]



    # Show open GitHub issues if GH_TOKEN is set
    gh_token = os.environ.get("GH_TOKEN")
    if gh_token:
        try:
            cmd = "gh issue list --state open --per-page 5 --json number,title,state,createdAt"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30, env={**os.environ, "GH_TOKEN": gh_token})
            if result.returncode == 0:
                issues = json.loads(result.stdout)
                if issues:
                    parts += ["", "Open GitHub issues:", ""]
                    for issue in issues:
                        parts.append(f"  #{issue['number']}: {issue['title']}")
        except Exception:
            pass



    if message.strip():
        parts += ["", "Someone started this run by hand and left you this:",
                  message.strip(), "", "It is a message, not an order."]
    else:
        parts += ["", "Nobody asked for anything. Work on what you want."]

    return "\n".join(p for p in parts if p is not None)
