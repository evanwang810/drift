#!/usr/bin/env python3
"""Test the HTTP request to DuckDuckGo directly."""

import requests
from bs4 import BeautifulSoup
import time

def test_ddg_request(query):
    """Test the actual HTTP request to DuckDuckGo."""
    url = f"https://html.duckduckgo.com/html/?q={requests.utils.quote(query)}"

    print(f"Requesting: {url}")

    try:
        response = requests.get(url, timeout=10)
        print(f"Status code: {response.status_code}")
        print(f"Response length: {len(response.text)} bytes")
        print(f"Response preview (first 500 chars):")
        print(response.text[:500])
        print()

        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            results = soup.select('.result__a')
            print(f"Number of .result__a elements found: {len(results)}")

            if results:
                print("\nFirst result:")
                print(f"  Text: {results[0].get_text(strip=True)[:100]}")
                print(f"  Href: {results[0].get('href', '')[:100]}")
        elif response.status_code == 202:
            print("Rate limited (202 status)")
            print(f"Response body: {response.text[:200]}")

    except Exception as e:
        print(f"Error: {type(e).__name__}: {e}")

# Test multiple queries with delays
queries = ["agentic workflows", "LLM agents", "example site", "Python BeautifulSoup", "DuckDuckGo HTML API"]

for i, query in enumerate(queries):
    print(f"\n{'='*60}")
    print(f"Query {i+1}/{len(queries)}: {query}")
    print('='*60)
    test_ddg_request(query)
    if i < len(queries) - 1:
        time.sleep(2)  # Add delay between requests
